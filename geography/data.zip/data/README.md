# About data-zambia_shapefiles
Repository consisting of payload of shapefiles for The Republic of Zambia

## Data sources
cso-shapefiles -- Central Statistical Office of Zambia
gadm-shapefiles -- http://www.gadm.org
